#include <iostream>
#include "matrix.h"

int main() {
	Matrix bh;
	bh.bHat();
	return 0;
}
